#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Импортируем библиотеку pygame
from player import *
from blocks import *
from button import *
import pygame
from pygame import *

# Объявляем переменные
WIN_WIDTH = 800  # Ширина создаваемого окна
WIN_HEIGHT = 640  # Высота
DISPLAY = (WIN_WIDTH, WIN_HEIGHT)  # Группируем ширину и высоту в одну переменную
BACKGROUND_COLOR = "#004400"
COLOR = (235, 255, 235)
COLOR1 = (3, 64, 3)
B_COLOR = (161, 161, 161)
B_COLOR1 = (59, 59, 59)
level_2_block = True
level_3_block = True
level_4_block = True
level_5_block = True


class Camera(object):
    def __init__(self, camera_func, width, height):
        self.camera_func = camera_func
        self.state = Rect(0, 0, width, height)

    def apply(self, target):
        return target.rect.move(self.state.topleft)

    def update(self, target):
        self.state = self.camera_func(self.state, target.rect)


def camera_configure(camera, target_rect):
    l, t, _, _ = target_rect
    _, _, w, h = camera
    l, t = -l + WIN_WIDTH / 2, -t + WIN_HEIGHT / 2

    l = min(0, l)  # Не движемся дальше левой границы
    l = max(-(camera.width - WIN_WIDTH), l)  # Не движемся дальше правой границы
    t = max(-(camera.height - WIN_HEIGHT), t)  # Не движемся дальше нижней границы
    t = min(0, t)  # Не движемся дальше верхней границы

    return Rect(l, t, w, h)


def gameWonAnimation(pg, screen, level):
    sc = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
    sc.fill((200, 255, 200))
    font = pg.font.Font(None, 60)

    if level != 'five':
        text = font.render("Поздравляю! Ты прошёл уровень!", True, (0, 100, 0))
        place = text.get_rect(center=(400, 270))
        sc.blit(text, place)
        bt1 = Button()
        button1 = bt1.create_button(screen, Color(COLOR), 200, 350, 400, 90, 50, 'Следующий уровень', Color(COLOR1))
        button2 = bt1.create_button(screen, Color(COLOR), 10, 10, 100, 50, 14, 'На главную', Color(COLOR1))
        UnblockingLevel(level)
    else:
        text = font.render("На этом все", True, (0, 100, 0))
        place = text.get_rect(center=(400, 220))
        sc.blit(text, place)
        text = font.render("Чтобы выйти нажмите на крестик", True, (0, 100, 0))
        place = text.get_rect(center=(400, 270))
        sc.blit(text, place)
        bt1 = Button()
        button1 = bt1.create_button(screen, Color(COLOR), 200, 350, 400, 90, 50, 'Начать сначала', Color(COLOR1))
    pg.display.update()

    while 1:
        for i in pygame.event.get():
            if i.type == pygame.QUIT:
                exit()
            if i.type == pygame.MOUSEBUTTONDOWN and i.button == 1:
                mouse_pos = pygame.mouse.get_pos()
                if 200 <= mouse_pos[0] <= 600 and 350 <= mouse_pos[1] <= 440:
                    if level == 'one':
                        level2()
                    elif level == 'two':
                        level3()
                    elif level == 'three':
                        level4()
                    else:
                        global level_2_block, level_5_block, level_3_block, level_4_block
                        level_2_block = True
                        level_3_block = True
                        level_4_block = True
                        level_5_block = True
                        game(screen)
                if 10 <= mouse_pos[0] <= 110 and 10 <= mouse_pos[1] <= 60:
                    game(screen)


def UnblockingLevel(level):
    if level == 'one':
        global level_2_block
        level_2_block = False
    elif level == 'two':
        global level_3_block
        level_3_block = False
    elif level == 'three':
        global level_4_block
        level_4_block = False
    elif level == 'four':
        global level_5_block
        level_5_block = False


def level2():
    pygame.init()  # Инициация PyGame, обязательная строчка
    screen = pygame.display.set_mode(DISPLAY)  # Создаем окошко
    pygame.display.set_caption("The best game in your life")  # Пишем в шапку
    bg = Surface((WIN_WIDTH, WIN_HEIGHT))  # Создание видимой поверхности
    # будем использовать как фон
    bg.fill(Color(BACKGROUND_COLOR))  # Заливаем поверхность сплошным цветом

    hero = Player(1000, 590)  # создаем героя по (x,y) координатам
    left = right = False  # по умолчанию - стоим
    up = False

    entities = pygame.sprite.Group()  # Все объекты
    platforms = []  # то, во что мы будем врезаться или опираться

    entities.add(hero)

    level = [
        "----------------------------------",
        "-                                -",
        "-                       --       -",
        "-                                -",
        "-            --                  -",
        "-                                -",
        "-*                               -",
        "-                                -",
        "-                   ----     --- -",
        "-                                -",
        "--                               -",
        "-                                -",
        "-                            --- -",
        "-                                -",
        "-                                -",
        "-      ---                       -",
        "-                                -",
        "-   -------         ----         -",
        "-                                -",
        "-                         -      -",
        "-                            --  -",
        "-                                -",
        "-                                -",
        "----------------------------------"]

    timer = pygame.time.Clock()
    x = y = 0  # координаты
    for row in level:  # вся строка
        for col in row:  # каждый символ
            if col == "-":
                pf = Platform(x, y)
                entities.add(pf)
                platforms.append(pf)
            elif col == '*':
                pf = Platform_Win(x, y)
                entities.add(pf)
                platforms.append(pf)

            x += PLATFORM_WIDTH  # блоки платформы ставятся на ширине блоков
        y += PLATFORM_HEIGHT  # то же самое и с высотой
        x = 0  # на каждой новой строчке начинаем с нуля

    total_level_width = len(level[0]) * PLATFORM_WIDTH  # Высчитываем фактическую ширину уровня
    total_level_height = len(level) * PLATFORM_HEIGHT  # высоту

    camera = Camera(camera_configure, total_level_width, total_level_height)
    running = True
    while running:  # Основной цикл программы
        timer.tick(60)
        for e in pygame.event.get():  # Обрабатываем события
            if e.type == QUIT:
                running = False
            if hero.collide(hero.xvel, hero.yvel, platforms):
                gameWonAnimation(pygame, screen, 'two')
                running = False
            if e.type == KEYDOWN and e.key == K_UP:
                up = True
            if e.type == KEYDOWN and e.key == K_LEFT:
                left = True
            if e.type == KEYDOWN and e.key == K_RIGHT:
                right = True

            if e.type == KEYUP and e.key == K_UP:
                up = False
            if e.type == KEYUP and e.key == K_RIGHT:
                right = False
            if e.type == KEYUP and e.key == K_LEFT:
                left = False

        screen.blit(bg, (0, 0))  # Каждую итерацию необходимо всё перерисовывать

        camera.update(hero)  # центризируем камеру относительно персонажа
        hero.update(left, right, up, platforms)  # передвижение
        # entities.draw(screen) # отображение
        for e in entities:
            screen.blit(e.image, camera.apply(e))

        pygame.display.update()  # обновление и вывод всех изменений на экран


def level1():
    pygame.init()  # Инициация PyGame, обязательная строчка
    screen = pygame.display.set_mode(DISPLAY)  # Создаем окошко
    pygame.display.set_caption("The best game in your life")  # Пишем в шапку
    bg = Surface((WIN_WIDTH, WIN_HEIGHT))  # Создание видимой поверхности
    # будем использовать как фон
    bg.fill(Color(BACKGROUND_COLOR))  # Заливаем поверхность сплошным цветом

    hero = Player(45, 55)  # создаем героя по (x,y) координатам
    left = right = False  # по умолчанию - стоим
    up = False

    entities = pygame.sprite.Group()  # Все объекты
    platforms = []  # то, во что мы будем врезаться или опираться

    entities.add(hero)

    level = [
        "----------------------------------",
        "-                                -",
        "-                                -",
        "-                                -",
        "-                               *-",
        "-                                -",
        "--                               -",
        "-                                -",
        "-                               --",
        "-                                -",
        "-                                -",
        "-                        --      -",
        "-                                -",
        "-                                -",
        "-                 --             -",
        "-                                -",
        "-                                -",
        "-          --                    -",
        "-                                -",
        "-                                -",
        "-     --                         -",
        "-                                -",
        "-                                -",
        "----------------------------------"]

    timer = pygame.time.Clock()
    x = y = 0  # координаты
    for row in level:  # вся строка
        for col in row:  # каждый символ
            if col == "-":
                pf = Platform(x, y)
                entities.add(pf)
                platforms.append(pf)
            elif col == '*':
                pf = Platform_Win(x, y)
                entities.add(pf)
                platforms.append(pf)

            x += PLATFORM_WIDTH  # блоки платформы ставятся на ширине блоков
        y += PLATFORM_HEIGHT  # то же самое и с высотой
        x = 0  # на каждой новой строчке начинаем с нуля

    total_level_width = len(level[0]) * PLATFORM_WIDTH  # Высчитываем фактическую ширину уровня
    total_level_height = len(level) * PLATFORM_HEIGHT  # высоту

    camera = Camera(camera_configure, total_level_width, total_level_height)
    running = True
    while running:  # Основной цикл программы
        timer.tick(60)
        for e in pygame.event.get():  # Обрабатываем события
            if e.type == QUIT:
                running = False
            if hero.collide(hero.xvel, hero.yvel, platforms):
                gameWonAnimation(pygame, screen, 'one')
                running = False
            if e.type == KEYDOWN and e.key == K_UP:
                up = True
            if e.type == KEYDOWN and e.key == K_LEFT:
                left = True
            if e.type == KEYDOWN and e.key == K_RIGHT:
                right = True

            if e.type == KEYUP and e.key == K_UP:
                up = False
            if e.type == KEYUP and e.key == K_RIGHT:
                right = False
            if e.type == KEYUP and e.key == K_LEFT:
                left = False

        screen.blit(bg, (0, 0))  # Каждую итерацию необходимо всё перерисовывать

        camera.update(hero)  # центризируем камеру относительно персонажа
        hero.update(left, right, up, platforms)  # передвижение
        # entities.draw(screen) # отображение
        for e in entities:
            screen.blit(e.image, camera.apply(e))

        pygame.display.update()  # обновление и вывод всех изменений на экран


def level3():
    pygame.init()  # Инициация PyGame, обязательная строчка
    screen = pygame.display.set_mode(DISPLAY)  # Создаем окошко
    pygame.display.set_caption("The best game in your life")  # Пишем в шапку
    bg = Surface((WIN_WIDTH, WIN_HEIGHT))  # Создание видимой поверхности
    # будем использовать как фон
    bg.fill(Color(BACKGROUND_COLOR))  # Заливаем поверхность сплошным цветом

    hero = Player(45, 590)  # создаем героя по (x,y) координатам
    left = right = False  # по умолчанию - стоим
    up = False

    entities = pygame.sprite.Group()  # Все объекты
    platforms = []  # то, во что мы будем врезаться или опираться

    entities.add(hero)

    level = [
        "----------------------------------",
        "-                                -",
        "-                                -",
        "-                               *-",
        "-                                -",
        "-                               --",
        "-                                -",
        "-              ---               -",
        "-                                -",
        "-                      --        -",
        "-                                -",
        "-         --                     -",
        "-                    ---         -",
        "-                                -",
        "-         ---                    -",
        "-                                -",
        "-                                -",
        "--                               -",
        "-                                -",
        "-                                -",
        "-                                -",
        "-     --                         -",
        "-                                -",
        "----------------------------------"]

    timer = pygame.time.Clock()
    x = y = 0  # координаты
    for row in level:  # вся строка
        for col in row:  # каждый символ
            if col == "-":
                pf = Platform(x, y)
                entities.add(pf)
                platforms.append(pf)
            elif col == '*':
                pf = Platform_Win(x, y)
                entities.add(pf)
                platforms.append(pf)

            x += PLATFORM_WIDTH  # блоки платформы ставятся на ширине блоков
        y += PLATFORM_HEIGHT  # то же самое и с высотой
        x = 0  # на каждой новой строчке начинаем с нуля

    total_level_width = len(level[0]) * PLATFORM_WIDTH  # Высчитываем фактическую ширину уровня
    total_level_height = len(level) * PLATFORM_HEIGHT  # высоту

    camera = Camera(camera_configure, total_level_width, total_level_height)
    running = True
    while running:  # Основной цикл программы
        timer.tick(60)
        for e in pygame.event.get():  # Обрабатываем события
            if e.type == QUIT:
                running = False
            if hero.collide(hero.xvel, hero.yvel, platforms):
                gameWonAnimation(pygame, screen, 'three')
                running = False
            if e.type == KEYDOWN and e.key == K_UP:
                up = True
            if e.type == KEYDOWN and e.key == K_LEFT:
                left = True
            if e.type == KEYDOWN and e.key == K_RIGHT:
                right = True

            if e.type == KEYUP and e.key == K_UP:
                up = False
            if e.type == KEYUP and e.key == K_RIGHT:
                right = False
            if e.type == KEYUP and e.key == K_LEFT:
                left = False

        screen.blit(bg, (0, 0))  # Каждую итерацию необходимо всё перерисовывать

        camera.update(hero)  # центризируем камеру относительно персонажа
        hero.update(left, right, up, platforms)  # передвижение
        # entities.draw(screen) # отображение
        for e in entities:
            screen.blit(e.image, camera.apply(e))
        pygame.display.update()  # обновление и вывод всех изменений на экран


def level4():
    pygame.init()  # Инициация PyGame, обязательная строчка
    screen = pygame.display.set_mode(DISPLAY)  # Создаем окошко
    pygame.display.set_caption("The best game in your life")  # Пишем в шапку
    bg = Surface((WIN_WIDTH, WIN_HEIGHT))  # Создание видимой поверхности
    # будем использовать как фон
    bg.fill(Color(BACKGROUND_COLOR))  # Заливаем поверхность сплошным цветом

    hero = Player(50, 50)  # создаем героя по (x,y) координатам
    left = right = False  # по умолчанию - стоим
    up = False

    entities = pygame.sprite.Group()  # Все объекты
    platforms = []  # то, во что мы будем врезаться или опираться

    entities.add(hero)

    level = [
        "-------------------------------------",
        "-                                   -",
        "-                                   -",
        "-------------------------------- ----",
        "-                                   -",
        "-                                   -",
        "--- ---------------------------------",
        "-                                   -",
        "-                                   -",
        "-------------------------------- ----",
        "-                                   -",
        "-                                   -",
        "-                                   -",
        "------------ ------------------------",
        "-                                   -",
        "-                                   -",
        "---------------------------------- --",
        "-                                   -",
        "-                                   -",
        "-                                   -",
        "-                                   -",
        "-                                   -",
        "-                                   -",
        "-                                   -",
        "-                                   -",
        "--- ---------------------------------",
        "-                                   -",
        "-                                   -",
        "-                                  *-",
        "-------------------------------------"]

    timer = pygame.time.Clock()
    x = y = 0  # координаты
    for row in level:  # вся строка
        for col in row:  # каждый символ
            if col == "-":
                pf = Platform(x, y)
                entities.add(pf)
                platforms.append(pf)
            elif col == '*':
                pf = Platform_Win(x, y)
                entities.add(pf)
                platforms.append(pf)

            x += PLATFORM_WIDTH  # блоки платформы ставятся на ширине блоков
        y += PLATFORM_HEIGHT  # то же самое и с высотой
        x = 0  # на каждой новой строчке начинаем с нуля

    total_level_width = len(level[0]) * PLATFORM_WIDTH  # Высчитываем фактическую ширину уровня
    total_level_height = len(level) * PLATFORM_HEIGHT  # высоту

    camera = Camera(camera_configure, total_level_width, total_level_height)
    running = True
    while running:  # Основной цикл программы
        timer.tick(60)
        for e in pygame.event.get():  # Обрабатываем события
            if e.type == QUIT:
                running = False
            if hero.collide(hero.xvel, hero.yvel, platforms):
                gameWonAnimation(pygame, screen, 'four')
                running = False
            if e.type == KEYDOWN and e.key == K_UP:
                up = True
            if e.type == KEYDOWN and e.key == K_LEFT:
                left = True
            if e.type == KEYDOWN and e.key == K_RIGHT:
                right = True

            if e.type == KEYUP and e.key == K_UP:
                up = False
            if e.type == KEYUP and e.key == K_RIGHT:
                right = False
            if e.type == KEYUP and e.key == K_LEFT:
                left = False

        screen.blit(bg, (0, 0))  # Каждую итерацию необходимо всё перерисовывать

        camera.update(hero)  # центризируем камеру относительно персонажа
        hero.update(left, right, up, platforms)  # передвижение
        # entities.draw(screen) # отображение
        for e in entities:
            screen.blit(e.image, camera.apply(e))
        pygame.display.update()  # обновление и вывод всех изменений на экран


def level5():
    pygame.init()  # Инициация PyGame, обязательная строчка
    screen = pygame.display.set_mode(DISPLAY)  # Создаем окошко
    pygame.display.set_caption("The best game in your life")  # Пишем в шапку
    bg = Surface((WIN_WIDTH, WIN_HEIGHT))  # Создание видимой поверхности
    # будем использовать как фон
    bg.fill(Color(BACKGROUND_COLOR))  # Заливаем поверхность сплошным цветом

    hero = Player(50, 700)  # создаем героя по (x,y) координатам
    left = right = False  # по умолчанию - стоим
    up = False

    entities = pygame.sprite.Group()  # Все объекты
    platforms = []  # то, во что мы будем врезаться или опираться

    entities.add(hero)

    level = [
        "-------------------------------------",
        "-                                   -",
        "-                                   -",
        "-*                                  -",
        "--                                  -",
        "-     -                             -",
        "-                                   -",
        "-                              -    -",
        "-            -                      -",
        "-                     -             -",
        "-                                   -",
        "-                -                  -",
        "-                                   -",
        "-                                   -",
        "------------ ------------------------",
        "-                                   -",
        "-                                   -",
        "-     ----------                    -",
        "-     -        -  --                -",
        "-     -        -                    -",
        "-------  ----  -                    -",
        "-        -  -  -     --------       -",
        "-        -  -  -     -              -",
        "----------  -  -     -              -",
        "-           -  -     -   ---------  -",
        "-------------  -                 -  -",
        "-              -                 -  -",
        "-              -     --------    -  -",
        "-   ------------     -           -  -",
        "-                    -           -  -",
        "-                    -     -------  -",
        "-                    -     -        -",
        "-                          -        -",
        "-------------------------------------"]

    timer = pygame.time.Clock()
    x = y = 0  # координаты
    for row in level:  # вся строка
        for col in row:  # каждый символ
            if col == "-":
                pf = Platform(x, y)
                entities.add(pf)
                platforms.append(pf)
            elif col == '*':
                pf = Platform_Win(x, y)
                entities.add(pf)
                platforms.append(pf)

            x += PLATFORM_WIDTH  # блоки платформы ставятся на ширине блоков
        y += PLATFORM_HEIGHT  # то же самое и с высотой
        x = 0  # на каждой новой строчке начинаем с нуля

    total_level_width = len(level[0]) * PLATFORM_WIDTH  # Высчитываем фактическую ширину уровня
    total_level_height = len(level) * PLATFORM_HEIGHT  # высоту

    camera = Camera(camera_configure, total_level_width, total_level_height)
    running = True
    while running:  # Основной цикл программы
        timer.tick(60)
        for e in pygame.event.get():  # Обрабатываем события
            if e.type == QUIT:
                running = False
            if hero.collide(hero.xvel, hero.yvel, platforms):
                gameWonAnimation(pygame, screen, 'five')
                running = False
            if e.type == KEYDOWN and e.key == K_UP:
                up = True
            if e.type == KEYDOWN and e.key == K_LEFT:
                left = True
            if e.type == KEYDOWN and e.key == K_RIGHT:
                right = True

            if e.type == KEYUP and e.key == K_UP:
                up = False
            if e.type == KEYUP and e.key == K_RIGHT:
                right = False
            if e.type == KEYUP and e.key == K_LEFT:
                left = False

        screen.blit(bg, (0, 0))  # Каждую итерацию необходимо всё перерисовывать

        camera.update(hero)  # центризируем камеру относительно персонажа
        hero.update(left, right, up, platforms)  # передвижение
        # entities.draw(screen) # отображение
        for e in entities:
            screen.blit(e.image, camera.apply(e))
        pygame.display.update()  # обновление и вывод всех изменений на экран


def game(screen):
    pygame.init()  # Инициация PyGame, обязательная строчка
    screen = pygame.display.set_mode(DISPLAY)  # Создаем окошко
    pygame.display.set_caption("The best game in your life")  # Пишем в шапку
    bg = Surface((WIN_WIDTH, WIN_HEIGHT))  # Создание видимой поверхности
    # будем использовать как фон
    bg.fill(Color(BACKGROUND_COLOR))  # Заливаем поверхность сплошным цветом

    sc = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
    sc.fill((200, 255, 200))
    bt1 = Button()
    button1 = bt1.create_button(screen, Color(COLOR), 125, 150, 150, 150, 200, '1', Color((224, 0, 0)))
    if level_2_block:
        button2 = bt1.create_button(screen, Color(B_COLOR), 325, 150, 150, 150, 200, '2', Color(B_COLOR1))
    else:
        button2 = bt1.create_button(screen, Color(COLOR), 325, 150, 150, 150, 200, '2', Color((224, 0, 0)))
    if level_3_block:
        button3 = bt1.create_button(screen, Color(B_COLOR), 525, 150, 150, 150, 200, '3', Color(B_COLOR1))
    else:
        button3 = bt1.create_button(screen, Color(COLOR), 525, 150, 150, 150, 200, '3', Color((224, 0, 0)))
    if level_4_block:
        button4 = bt1.create_button(screen, Color(B_COLOR), 225, 350, 150, 150, 200, '4', Color(B_COLOR1))
    else:
        button4 = bt1.create_button(screen, Color(COLOR), 225, 350, 150, 150, 200, '4', Color((224, 0, 0)))
    if level_5_block:
        button5 = bt1.create_button(screen, Color(B_COLOR), 425, 350, 150, 150, 200, '5', Color(B_COLOR1))
    else:
        button5 = bt1.create_button(screen, Color(COLOR), 425, 350, 150, 150, 200, '5', Color((224, 0, 0)))
    pygame.display.update()  # обновление и вывод всех изменений на экран
    running = True
    while running:
        for e in pygame.event.get():
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                mouse_pos = pygame.mouse.get_pos()
                if 125 <= mouse_pos[0] <= 275 and 150 <= mouse_pos[1] <= 300:
                    level1()
                elif 325 <= mouse_pos[0] <= 475 and 150 <= mouse_pos[1] <= 300:
                    if not level_2_block:
                        level2()
                elif 525 <= mouse_pos[0] <= 675 and 150 <= mouse_pos[1] <= 300:
                    if not level_3_block:
                        level3()
                elif 225 <= mouse_pos[0] <= 375 and 350 <= mouse_pos[1] <= 500:
                    if not level_4_block:
                        level4()
                elif 425 <= mouse_pos[0] <= 575 and 350 <= mouse_pos[1] <= 500:
                    if not level_5_block:
                        level5()
            if e.type == QUIT:
                running = False